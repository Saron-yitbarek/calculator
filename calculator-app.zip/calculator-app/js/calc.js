const previousOperand = document.querySelector(".previous-operand");
const currentOperand = document.querySelector(".current-operand");
const btnDelete = document.querySelector(".delete");
const btnResult = document.querySelector(".output");
const btnReset = document.querySelector(".reset");
const btnOperands = document.querySelectorAll(".num");
const btnOperator = document.querySelectorAll(".operator");

btnOperands.forEach(function (operand) {
	operand.addEventListener("click", function () {
		currentOperand.textContent += operand.textContent; //Read and append
	});
});

btnDelete.addEventListener("click", function () {
	currentOperand.textContent = currentOperand.textContent.slice(0, -1);
});

btnReset.addEventListener("click", function () {
	currentOperand.textContent = "";
	previousOperand.textContent = "";
});

const computeOperands = function (operator) {
	let result;
	let previousOperandParsed = parseFloat(previousOperand.textContent);
	let currentOperandParsed = parseFloat(currentOperand.textContent);
	if (isNaN(previousOperandParsed)) {
		previousOperand.textContent = `${currentOperand.textContent} ${operator.textContent}`;
		currentOperand.textContent = "";
		return;
	} else if (isNaN(currentOperandParsed)) return;

	switch (operator.textContent) {
		case "+":
			result = previousOperandParsed + currentOperandParsed;
			break;
		case "-":
			result = previousOperandParsed - currentOperandParsed;
			break;
		case "*":
			result = previousOperandParsed * currentOperandParsed;
			break;
		case "/":
			result = previousOperandParsed / currentOperandParsed;
			break;
		default:
			return;
	}

	previousOperand.textContent = ` ${result} ${operator.textContent} `;
	currentOperand.textContent = "";
};

btnOperator.forEach(function (operator) {
	operator.addEventListener("click", function () {
		computeOperands(operator);
	});
});

btnResult.addEventListener("click", function () {
	const previousOperandSpit = previousOperand.textContent.split(" ");
	const operatorType = previousOperandSpit[1];
	let previousOperandParsed = parseFloat(previousOperandSpit[0]);
	let currentOperandParsed = parseFloat(currentOperand.textContent);
	let result;
	switch (operatorType) {
		case "+":
			result = previousOperandParsed + currentOperandParsed;
			break;
		case "-":
			result = previousOperandParsed - currentOperandParsed;
			break;
		case "*":
			result = previousOperandParsed * currentOperandParsed;
			break;
		case "/":
			result = previousOperandParsed / currentOperandParsed;
			break;
		default:
			return;
	}
	previousOperand.textContent = "";
	currentOperand.textContent = result;
});
