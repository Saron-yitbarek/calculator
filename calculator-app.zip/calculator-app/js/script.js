//Login
const btnLogin = document.querySelector(".btnlogin");
const inputUsername = document.querySelector("#username");
const inputPassword = document.querySelector("#password");

btnLogin.addEventListener("click", function (e) {
	if (inputUsername.value === "admin" && inputPassword.value === "1234") {
		window.location.href = "http://127.0.0.1:5500/calculator.html";
	} else {
		document.querySelector("#loginstatus").textContent = "Incorrect Credential";
	}
});
